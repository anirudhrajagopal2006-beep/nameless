"use client"

import { useCallback, useState } from "react"
import { Upload, FileText, X } from "lucide-react"
import { cn } from "@/lib/utils"

interface FileUploadProps {
  accept: string
  label: string
  description: string
  onFileSelect: (content: string, fileName: string) => void
  fileName?: string
  onClear?: () => void
}

export function FileUpload({
  accept,
  label,
  description,
  onFileSelect,
  fileName,
  onClear
}: FileUploadProps) {
  const [isDragging, setIsDragging] = useState(false)

  const handleFile = useCallback(
    (file: File) => {
      const reader = new FileReader()
      reader.onload = (e) => {
        const content = e.target?.result as string
        onFileSelect(content, file.name)
      }
      reader.readAsText(file)
    },
    [onFileSelect]
  )

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault()
      setIsDragging(false)
      const file = e.dataTransfer.files[0]
      if (file) handleFile(file)
    },
    [handleFile]
  )

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(true)
  }, [])

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(false)
  }, [])

  return (
    <div
      className={cn(
        "relative flex flex-col items-center justify-center rounded-lg border-2 border-dashed p-6 transition-all",
        isDragging
          ? "border-primary bg-primary/10"
          : "border-border bg-card hover:border-primary/50 hover:bg-card/80",
        fileName && "border-primary/50 bg-primary/5"
      )}
      onDrop={handleDrop}
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
    >
      {fileName ? (
        <div className="flex items-center gap-3">
          <FileText className="h-8 w-8 text-primary" />
          <div className="flex flex-col">
            <span className="text-sm font-medium text-foreground">{fileName}</span>
            <span className="text-xs text-muted-foreground">File loaded successfully</span>
          </div>
          {onClear && (
            <button
              onClick={onClear}
              className="ml-2 rounded-full p-1 hover:bg-secondary"
              aria-label="Clear file"
            >
              <X className="h-4 w-4 text-muted-foreground" />
            </button>
          )}
        </div>
      ) : (
        <>
          <Upload className="mb-3 h-10 w-10 text-muted-foreground" />
          <p className="mb-1 text-sm font-medium text-foreground">{label}</p>
          <p className="mb-3 text-xs text-muted-foreground">{description}</p>
          <label className="cursor-pointer">
            <span className="rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:bg-primary/90">
              Browse Files
            </span>
            <input
              type="file"
              accept={accept}
              className="hidden"
              onChange={(e) => {
                const file = e.target.files?.[0]
                if (file) handleFile(file)
              }}
            />
          </label>
        </>
      )}
    </div>
  )
}
