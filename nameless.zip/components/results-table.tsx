"use client"

import { useState } from "react"
import { ChevronUp, ChevronDown } from "lucide-react"
import type { RiskResult } from "@/lib/csv-parser"
import { cn } from "@/lib/utils"

interface ResultsTableProps {
  results: RiskResult[]
}

type SortKey = keyof RiskResult
type SortDirection = "asc" | "desc"

export function ResultsTable({ results }: ResultsTableProps) {
  const [sortKey, setSortKey] = useState<SortKey>("risk")
  const [sortDirection, setSortDirection] = useState<SortDirection>("desc")

  const sortedResults = [...results].sort((a, b) => {
    const aVal = a[sortKey]
    const bVal = b[sortKey]
    
    if (typeof aVal === "number" && typeof bVal === "number") {
      return sortDirection === "asc" ? aVal - bVal : bVal - aVal
    }
    
    return sortDirection === "asc"
      ? String(aVal).localeCompare(String(bVal))
      : String(bVal).localeCompare(String(aVal))
  })

  const handleSort = (key: SortKey) => {
    if (sortKey === key) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc")
    } else {
      setSortKey(key)
      setSortDirection("desc")
    }
  }

  const SortHeader = ({ label, columnKey }: { label: string; columnKey: SortKey }) => (
    <th
      className="cursor-pointer select-none px-4 py-3 text-left text-xs font-medium uppercase tracking-wider text-muted-foreground hover:text-foreground"
      onClick={() => handleSort(columnKey)}
    >
      <div className="flex items-center gap-1">
        {label}
        {sortKey === columnKey && (
          sortDirection === "asc" ? (
            <ChevronUp className="h-4 w-4" />
          ) : (
            <ChevronDown className="h-4 w-4" />
          )
        )}
      </div>
    </th>
  )

  const getSeverityColor = (severity: number) => {
    if (severity >= 4) return "text-red-400"
    if (severity >= 3) return "text-yellow-400"
    return "text-green-400"
  }

  const getSpecializationBadge = (spec: string) => {
    const colors: Record<string, string> = {
      TRAUMA: "bg-red-500/20 text-red-400",
      CARDIO: "bg-pink-500/20 text-pink-400",
      GENERAL: "bg-blue-500/20 text-blue-400"
    }
    return colors[spec] || "bg-gray-500/20 text-gray-400"
  }

  const getRiskColor = (risk: number) => {
    if (risk >= 75) return "text-red-400"
    if (risk >= 50) return "text-orange-400"
    if (risk >= 25) return "text-yellow-400"
    return "text-green-400"
  }

  return (
    <div className="overflow-hidden rounded-lg border bg-card">
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="border-b bg-secondary/50">
            <tr>
              <SortHeader label="Patient ID" columnKey="patient_id" />
              <SortHeader label="Severity" columnKey="severity" />
              <SortHeader label="Arrival Time" columnKey="arrival_time" />
              <SortHeader label="Treatment Time" columnKey="treatment_time" />
              <SortHeader label="Specialization" columnKey="specialization" />
              <SortHeader label="Risk Score" columnKey="risk" />
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {sortedResults.map((result, index) => (
              <tr
                key={result.patient_id}
                className={cn(
                  "transition-colors hover:bg-secondary/30",
                  index % 2 === 0 && "bg-secondary/10"
                )}
              >
                <td className="whitespace-nowrap px-4 py-3 text-sm font-medium text-foreground">
                  {result.patient_id}
                </td>
                <td className="whitespace-nowrap px-4 py-3 text-sm">
                  <span className={cn("font-semibold", getSeverityColor(result.severity))}>
                    {result.severity}
                  </span>
                </td>
                <td className="whitespace-nowrap px-4 py-3 text-sm text-muted-foreground">
                  {result.arrival_time}
                </td>
                <td className="whitespace-nowrap px-4 py-3 text-sm text-muted-foreground">
                  {result.treatment_time}
                </td>
                <td className="whitespace-nowrap px-4 py-3 text-sm">
                  <span
                    className={cn(
                      "inline-flex rounded-full px-2 py-1 text-xs font-medium",
                      getSpecializationBadge(result.specialization)
                    )}
                  >
                    {result.specialization}
                  </span>
                </td>
                <td className={cn("whitespace-nowrap px-4 py-3 text-sm font-semibold", getRiskColor(result.risk))}>
                  {result.risk.toLocaleString()}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
