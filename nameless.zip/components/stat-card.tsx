import { cn } from "@/lib/utils"

interface StatCardProps {
  label: string
  value: string | number
  icon?: React.ReactNode
  className?: string
  highlight?: boolean
}

export function StatCard({ label, value, icon, className, highlight }: StatCardProps) {
  return (
    <div
      className={cn(
        "flex flex-col rounded-lg border bg-card p-4",
        highlight && "border-primary bg-primary/10",
        className
      )}
    >
      <div className="mb-2 flex items-center justify-between">
        <span className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
          {label}
        </span>
        {icon && <span className="text-primary">{icon}</span>}
      </div>
      <span
        className={cn(
          "text-2xl font-bold",
          highlight ? "text-primary" : "text-foreground"
        )}
      >
        {value}
      </span>
    </div>
  )
}
