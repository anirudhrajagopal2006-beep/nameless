"use client"

import { useState, useMemo } from "react"
import { Activity, Users, Clock, Calculator, Heart, Download, FileSpreadsheet, AlertCircle } from "lucide-react"
import { FileUpload } from "./file-upload"
import { StatCard } from "./stat-card"
import { ResultsTable } from "./results-table"
import {
  parseCSV,
  calculateRisk,
  getStatistics,
  type Patient,
} from "@/lib/csv-parser"
import { Button } from "@/components/ui/button"

export function RiskCalculator() {
  const [csvContent, setCsvContent] = useState<string | null>(null)
  const [csvFileName, setCsvFileName] = useState<string>("")
  const [parseError, setParseError] = useState<string | null>(null)

  const patients = useMemo<Patient[]>(() => {
    if (!csvContent) return []
    try {
      setParseError(null)
      return parseCSV(csvContent)
    } catch (e) {
      setParseError(e instanceof Error ? e.message : "Failed to parse CSV file")
      return []
    }
  }, [csvContent])

  const riskResults = useMemo(() => {
    if (patients.length === 0) return null
    return calculateRisk(patients)
  }, [patients])

  const statistics = useMemo(() => {
    if (patients.length === 0 || !riskResults) return null
    return getStatistics(patients, riskResults.results)
  }, [patients, riskResults])

  const handleCsvUpload = (content: string, fileName: string) => {
    setParseError(null)
    setCsvContent(content)
    setCsvFileName(fileName)
  }

  const handleDownloadResults = () => {
    if (!riskResults || !statistics) return
    
    // Format output as per reference: array of treatments with estimated_total_risk
    const treatments = riskResults.results.map((result) => {
      const patient = patients.find(p => p.patient_id === result.patient_id)
      return {
        patient_id: result.patient_id,
        doctor_id: `Doctor_${result.specialization.charAt(0)}`,
        start_time: patient?.arrival_time ?? 0,
        end_time: (patient?.arrival_time ?? 0) + (patient?.treatment_time ?? 0),
      }
    })
    
    const output = {
      treatments,
      estimated_total_risk: riskResults.totalRisk,
    }
    
    const blob = new Blob([JSON.stringify(output, null, 2)], { type: "application/json" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = "submission.json"
    a.click()
    URL.revokeObjectURL(url)
  }

  const handleClearCsv = () => {
    setCsvContent(null)
    setCsvFileName("")
    setParseError(null)
  }

  return (
    <div className="mx-auto max-w-7xl px-4 py-8">
      {/* Header */}
      <div className="mb-8 text-center">
        <div className="mb-4 flex items-center justify-center gap-3">
          <Activity className="h-10 w-10 text-primary" />
          <h1 className="text-3xl font-bold tracking-tight text-foreground md:text-4xl">
            Patient Risk Calculator
          </h1>
        </div>
        <p className="mx-auto max-w-2xl text-balance text-muted-foreground">
          Upload patient data (CSV) to calculate risk scores. Risk is calculated as:{" "}
          <span className="font-mono text-primary">severity × treatment_time</span>
        </p>
      </div>

      {/* File Upload Section */}
      <div className="mb-8 mx-auto max-w-xl">
        <h2 className="mb-3 flex items-center gap-2 text-sm font-semibold text-foreground">
          <FileSpreadsheet className="h-5 w-5 text-primary" />
          Upload Patient Data (CSV)
        </h2>
        <FileUpload
          accept=".csv"
          label="Upload Patient CSV"
          description="Required columns: patient_id, severity, arrival_time, treatment_time, required_specialization"
          onFileSelect={handleCsvUpload}
          fileName={csvFileName}
          onClear={handleClearCsv}
        />
        {patients.length > 0 && (
          <p className="mt-2 text-sm text-muted-foreground">
            Loaded <span className="font-semibold text-primary">{patients.length}</span> patients
          </p>
        )}
      </div>

      {/* Parse Error */}
      {parseError && (
        <div className="mb-6 mx-auto max-w-xl rounded-lg border border-destructive/50 bg-destructive/10 p-4">
          <div className="flex items-center gap-2 text-destructive">
            <AlertCircle className="h-5 w-5" />
            <span className="font-semibold">Error parsing file</span>
          </div>
          <p className="mt-1 text-sm text-destructive">{parseError}</p>
        </div>
      )}

      {/* Results Section */}
      {riskResults && statistics && (
        <>
          {/* Total Risk Highlight */}
          <div className="mb-6 rounded-lg border-2 border-primary bg-primary/5 p-6 text-center">
            <div className="mb-2 flex items-center justify-center gap-2 text-sm font-medium uppercase tracking-wider text-muted-foreground">
              <Calculator className="h-4 w-4" />
              Total Estimated Risk
            </div>
            <div className="text-5xl font-bold text-primary">
              {riskResults.totalRisk.toLocaleString()}
            </div>
            <p className="mt-2 text-sm text-muted-foreground">
              Based on {riskResults.results.length} patients
            </p>
          </div>

          {/* Statistics Cards */}
          <div className="mb-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <StatCard
              label="Total Patients"
              value={statistics.totalPatients}
              icon={<Users className="h-5 w-5" />}
            />
            <StatCard
              label="Avg Severity"
              value={statistics.avgSeverity}
              icon={<Heart className="h-5 w-5" />}
            />
            <StatCard
              label="Avg Treatment Time"
              value={statistics.avgTreatmentTime}
              icon={<Clock className="h-5 w-5" />}
            />
            <StatCard
              label="Avg Risk"
              value={statistics.avgRisk}
              icon={<Activity className="h-5 w-5" />}
              highlight
            />
          </div>

          {/* Risk Range */}
          <div className="mb-6 grid gap-4 sm:grid-cols-2">
            <div className="flex items-center justify-between rounded-lg border bg-card p-4">
              <span className="text-sm font-medium text-muted-foreground">Minimum Risk</span>
              <span className="text-lg font-bold text-green-400">{statistics.minRisk}</span>
            </div>
            <div className="flex items-center justify-between rounded-lg border bg-card p-4">
              <span className="text-sm font-medium text-muted-foreground">Maximum Risk</span>
              <span className="text-lg font-bold text-red-400">{statistics.maxRisk}</span>
            </div>
          </div>

          {/* Specialization Breakdown */}
          <div className="mb-6">
            <h3 className="mb-3 text-sm font-semibold text-foreground">Patients by Specialization</h3>
            <div className="grid gap-4 sm:grid-cols-3">
              {Object.entries(statistics.specializationCounts).map(([spec, count]) => (
                <div
                  key={spec}
                  className="flex items-center justify-between rounded-lg border bg-card p-4"
                >
                  <div>
                    <span className="text-sm font-medium text-muted-foreground">{spec}</span>
                    <p className="text-xs text-muted-foreground/70">
                      Risk: {statistics.specializationRisk[spec]?.toLocaleString() || 0}
                    </p>
                  </div>
                  <span className="text-lg font-bold text-foreground">{count}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Severity Distribution */}
          <div className="mb-6">
            <h3 className="mb-3 text-sm font-semibold text-foreground">Severity Distribution</h3>
            <div className="flex flex-wrap gap-3">
              {Object.entries(statistics.severityCounts)
                .sort(([a], [b]) => Number(a) - Number(b))
                .map(([severity, count]) => (
                  <div
                    key={severity}
                    className="flex items-center gap-2 rounded-lg border bg-card px-4 py-2"
                  >
                    <span className="text-sm text-muted-foreground">Level {severity}:</span>
                    <span className="font-bold text-foreground">{count}</span>
                  </div>
                ))}
            </div>
          </div>

          {/* Download Button */}
          <div className="mb-6 flex justify-end">
            <Button onClick={handleDownloadResults} className="gap-2">
              <Download className="h-4 w-4" />
              Download Results
            </Button>
          </div>

          {/* Results Table */}
          <div>
            <h2 className="mb-4 text-lg font-semibold text-foreground">
              Detailed Risk Breakdown
            </h2>
            <ResultsTable results={riskResults.results} />
          </div>
        </>
      )}

      {/* Empty State */}
      {!riskResults && !parseError && (
        <div className="flex flex-col items-center justify-center rounded-lg border-2 border-dashed border-border py-16 text-center">
          <FileSpreadsheet className="mb-4 h-12 w-12 text-muted-foreground" />
          <h3 className="mb-2 text-lg font-semibold text-foreground">
            No Data Loaded
          </h3>
          <p className="max-w-md text-balance text-sm text-muted-foreground">
            Upload a patient CSV file to calculate risk scores. The file should contain columns for patient_id, severity, arrival_time, treatment_time, and required_specialization.
          </p>
        </div>
      )}
    </div>
  )
}
