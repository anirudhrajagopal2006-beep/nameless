export interface Patient {
  patient_id: string
  severity: number
  arrival_time: number
  treatment_time: number
  specialization: string
}

export interface RiskResult {
  patient_id: string
  severity: number
  arrival_time: number
  treatment_time: number
  risk: number
  specialization: string
}

export function parseCSV(csvText: string): Patient[] {
  const lines = csvText.trim().split('\n')
  const headers = lines[0].split(',').map(h => h.trim().toLowerCase())
  
  const patients: Patient[] = []
  
  for (let i = 1; i < lines.length; i++) {
    const values = lines[i].split(',').map(v => v.trim())
    if (values.length !== headers.length) continue
    
    const getIndex = (possibleNames: string[]) => {
      for (const name of possibleNames) {
        const idx = headers.indexOf(name.toLowerCase())
        if (idx !== -1) return idx
      }
      return -1
    }
    
    const idIdx = getIndex(['patient_id', 'id', 'patientid'])
    const sevIdx = getIndex(['severity', 'sev'])
    const arrIdx = getIndex(['arrival_time', 'arrival', 'arrivaltime'])
    const treatIdx = getIndex(['treatment_time', 'treatment', 'treatmenttime'])
    const specIdx = getIndex(['required_specialization', 'specialization', 'spec'])
    
    const patient: Patient = {
      patient_id: idIdx !== -1 ? values[idIdx] : `P${i}`,
      severity: sevIdx !== -1 ? parseInt(values[sevIdx], 10) : 0,
      arrival_time: arrIdx !== -1 ? parseInt(values[arrIdx], 10) : 0,
      treatment_time: treatIdx !== -1 ? parseInt(values[treatIdx], 10) : 0,
      specialization: specIdx !== -1 ? values[specIdx] : 'UNKNOWN'
    }
    
    if (patient.patient_id && !isNaN(patient.severity)) {
      patients.push(patient)
    }
  }
  
  return patients
}

export function calculateRisk(patients: Patient[]): { results: RiskResult[]; totalRisk: number } {
  const results: RiskResult[] = []
  let totalRisk = 0
  
  for (const patient of patients) {
    // Risk formula: severity * treatment_time
    const risk = patient.severity * patient.treatment_time
    totalRisk += risk
    
    results.push({
      patient_id: patient.patient_id,
      severity: patient.severity,
      arrival_time: patient.arrival_time,
      treatment_time: patient.treatment_time,
      risk,
      specialization: patient.specialization
    })
  }
  
  // Sort by risk (highest first)
  results.sort((a, b) => b.risk - a.risk)
  
  return { results, totalRisk }
}

export function getStatistics(patients: Patient[], results: RiskResult[]) {
  const totalPatients = patients.length
  const totalRisk = results.reduce((sum, r) => sum + r.risk, 0)
  const avgSeverity = patients.reduce((sum, p) => sum + p.severity, 0) / totalPatients || 0
  const avgTreatmentTime = patients.reduce((sum, p) => sum + p.treatment_time, 0) / totalPatients || 0
  const avgRisk = totalRisk / totalPatients || 0
  const maxRisk = Math.max(...results.map(r => r.risk))
  const minRisk = Math.min(...results.map(r => r.risk))
  
  const specializationCounts = patients.reduce((acc, p) => {
    acc[p.specialization] = (acc[p.specialization] || 0) + 1
    return acc
  }, {} as Record<string, number>)
  
  const specializationRisk = results.reduce((acc, r) => {
    acc[r.specialization] = (acc[r.specialization] || 0) + r.risk
    return acc
  }, {} as Record<string, number>)
  
  const severityCounts = patients.reduce((acc, p) => {
    acc[p.severity] = (acc[p.severity] || 0) + 1
    return acc
  }, {} as Record<number, number>)
  
  return {
    totalPatients,
    totalRisk,
    avgSeverity: avgSeverity.toFixed(2),
    avgTreatmentTime: avgTreatmentTime.toFixed(2),
    avgRisk: avgRisk.toFixed(2),
    maxRisk,
    minRisk,
    specializationCounts,
    specializationRisk,
    severityCounts
  }
}
