import { RiskCalculator } from "@/components/risk-calculator"

export default function Page() {
  return (
    <main className="min-h-screen bg-background">
      <RiskCalculator />
    </main>
  )
}
